#Change bot logs

open data.php file

You'll see botToken and chatID, resplace values with yours.
save file and exist.